# rusttp
A blazingly fast Python module for HTTP using Rust's reqwest
